class MimecastEndpoints:
    get_threat_intel_feed = "/api/ttp/threat-intel/get-feed"
