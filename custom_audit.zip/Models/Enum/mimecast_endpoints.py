class MimecastEndpoints:

    get_audit_events = '/api/audit/get-audit-events'
    refresh_access_key = '/api/login/login'
