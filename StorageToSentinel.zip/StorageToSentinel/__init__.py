"""Init for Netskope Azure storage to Sentinel."""

from .netskope_azure_storage_to_sentinel import NetskopeAzureStorageToSentinel
from ..SharedCode import utils
from ..SharedCode.logger import applogger


async def main(sharename: str):
    """Driver method for azure storage to sentinel."""
    state_manager_to_sentinel_obj = NetskopeAzureStorageToSentinel(sharename)
    await state_manager_to_sentinel_obj.driver_code()
