"""Netskope To Azure Storage Durable Orchaestrator."""

import logging
import json

from azure.durable_functions import DurableOrchestrationContext, Orchestrator


def orchestrator_function(context: DurableOrchestrationContext):
    parallel_tasks = [context.call_activity("StorageToSentinel"), context.call_activity("RemoveDuplicatesFromStorage")]
    outputs = yield context.task_all(parallel_tasks)
    return [outputs]


main = Orchestrator.create(orchestrator_function)
