"""Netskope To Azure Storage Durable Orchaestrator."""

import logging
import json
from ..SharedCode import utils
from azure.durable_functions import DurableOrchestrationContext, Orchestrator


def orchestrator_function(context: DurableOrchestrationContext):
    event_type_sub_type = utils.get_event_alert_type_subtype()
    sharename = event_type_sub_type.get("type_of_data") + event_type_sub_type.get("sub_type") + "data"
    parallel_tasks = [
        context.call_activity("StorageToSentinel", sharename),
        context.call_activity("RemoveDuplicatesFromStorage", sharename),
    ]
    outputs = yield context.task_all(parallel_tasks)
    return [outputs]


main = Orchestrator.create(orchestrator_function)
