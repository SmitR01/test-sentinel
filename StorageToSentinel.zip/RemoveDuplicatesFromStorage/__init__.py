"""Init for remove duplicates from Azure storage."""

import logging
import inspect
from ..RemoveDuplicatesFromStorage.remove_duplicates_in_azure_storage import RemoveDuplicatesInAzureStorage
from ..SharedCode.logger import applogger
from ..SharedCode import consts


def main(sharename: str):
    """Driver method for remove duplicates from azure storage."""
    __method_name = inspect.currentframe().f_code.co_name
    try:
        duplicate_share_name = sharename.rstrip("data") + "duplicationcheck"
        remove_duplicates_obj = RemoveDuplicatesInAzureStorage(sharename, duplicate_share_name)
        remove_duplicates_obj.list_file_names_and_remove_duplicate_data()
    except Exception:
        applogger.error(
            "{}(method={}) : {} : Error occurred in deduplication or file share not available for share-{}.".format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.NETSKOPE_AZURE_STORAGE_TO_SENTINEL,
                sharename,
            )
        )
