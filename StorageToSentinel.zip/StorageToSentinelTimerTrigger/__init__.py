"""Starts the function invocations at the given timer."""
import logging
import azure.functions as func
from azure.durable_functions import DurableOrchestrationClient


# async def main(mytimer: func.TimerRequest, starter: str) -> None:
#     """Start the durable orchestration."""
#     client = DurableOrchestrationClient(starter)
#     instance_id = await client.start_new("StorageToSentinelOrchestrator", None, None)
#     logging.info(f"Started Azure Storage To Sentinel orchestration with ID = '{instance_id}'.")
#     if mytimer.past_due:
#         logging.info("The timer is past due!")
async def main(mytimer: func.TimerRequest, starter: str):
    logging.info("Executing SentinelTimerTrigger function")
    client = DurableOrchestrationClient(starter)
    instance_id = "singleton_instance"
    existing_instance = await client.get_status(instance_id)
    if existing_instance is None or str(existing_instance.runtime_status) in ["None", "OrchestrationRuntimeStatus.Completed", "OrchestrationRuntimeStatus.Failed", "OrchestrationRuntimeStatus.Terminated"]:
        instance_id = await client.start_new("StorageToSentinelOrchestrator", instance_id)
        logging.info(f"Starting new orchestration - the runtime status is: {str(existing_instance.runtime_status)}")
    else:
        logging.info(f"Skipped orchestration - runtime status is : {str(existing_instance.runtime_status)}") 
    if mytimer.past_due:
        logging.info("The timer is past due!")
