"""Validate the parameters from consts."""
import inspect
from . import consts
from .logger import applogger
from .netskope_exception import NetskopeException


def validate_parameters(azure_function_name):
    """Validate the user input parameters.

    Args:
        azure_function_name (str): The name of the caller azure function for logging.

    Raises:
        NetskopeException: Netskope Custom Exception
    """
    __method_name = inspect.currentframe().f_code.co_name
    try:
        required_params = {
            "LogLevel": consts.LOG_LEVEL,
            "ConnectionString": consts.CONNECTION_STRING,
            "AlertsType": consts.ALERTS_TYPE_INPUT,
            "EventsType": consts.EVENTS_TYPE_INPUT,
            "ShareName": consts.SHARE_NAME,
            "NetskopeHostname": consts.NETSKOPE_HOSTNAME,
            "NetskopeToken": consts.NETSKOPE_TOKEN,
        }
        applogger.debug(
            "{}(method={}) : Checking if all the environment variables exist or not.".format(
                consts.LOGS_STARTS_WITH, __method_name
            )
        )
        missing_required_field = False
        for label, params in required_params.items():
            if not params or params == "":
                missing_required_field = True
                applogger.error(
                    '{}(method={}) : {} : "{}" field is not set in the environment please set '
                    "the environment variable and run the app.".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        azure_function_name,
                        label,
                    )
                )
        if missing_required_field:
            raise NetskopeException()
        # Verifying the Netskope Events Types input and Netskope Alerts Types input.
        incorrect_events = list(consts.EVENTS_TYPE_INPUT.difference(consts.EVENTS_LIST))
        incorrect_alerts = list(consts.ALERTS_TYPE_INPUT.difference(consts.ALERTS_LIST))
        events_alerts_subtype = consts.SHARE_NAME
        if len(incorrect_alerts) > 0:
            applogger.error(
                "{}(method={}) : {} : Incorrect alerts are {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, azure_function_name, str(incorrect_alerts)
                )
            )
        if len(incorrect_events) > 0:
            applogger.error(
                "{}(method={}) : {} : Incorrect events are {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, azure_function_name, str(incorrect_events)
                )
            )
        if len(incorrect_alerts) > 0 or len(incorrect_events) > 0:
            applogger.error(
                "{}(method={}) : {} : Incorrect alerts : {} and Incorrect events : {}".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    azure_function_name,
                    len(incorrect_alerts),
                    len(incorrect_events),
                )
            )
            raise NetskopeException()
        if not (events_alerts_subtype in consts.EVENTS_LIST or events_alerts_subtype in consts.ALERTS_LIST):
            applogger.error(
                "{}(method={}) : {} : Incorrect alerts or events type are {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, azure_function_name, str(events_alerts_subtype)
                )
            )
            raise NetskopeException()
    except NetskopeException:
        applogger.error(
            "{}(method={}) : {} : Error while validating environment variables.".format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                azure_function_name,
            )
        )
        raise NetskopeException()
    except Exception as error:
        applogger.error(
            "{}(method={}) : {} : Error while validating environment variables. Error-{}.".format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                azure_function_name,
                error,
            )
        )
        raise NetskopeException()
