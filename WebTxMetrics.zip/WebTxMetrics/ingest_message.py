"""Module to Ingest metrics in sentinel."""
import json
import requests
import inspect
from ..SharedCode import consts
from ..SharedCode.logger import applogger
from ..SharedCode.netskope_exception import NetskopeException
from .sentinel import post_data


def ingest_backlog_unacked_message():
    """Fetch and Ingest WebTx Metrics to Sentinel."""
    __method_name = inspect.currentframe().f_code.co_name
    try:
        headers = {"Netskope-Api-Token": consts.NETSKOPE_TOKEN}
        parameters = {"hours": consts.HOURS}
        res = requests.get(
            consts.WEBTX_METRICS_URL.format(hostname=consts.NETSKOPE_HOSTNAME), headers=headers, params=parameters
        )
        json_data = res.json()
        subscription = list(json_data["result"]["subscription/backlog_message_count"].keys())[0]
        backlog_message = json_data["result"]["subscription/backlog_message_count"][subscription]["partition_num: 1"]
        oldest_unacked_message = json_data["result"]["subscription/oldest_unacked_message_age"][subscription][
            "partition_num: 1"
        ]
        data_to_post = []
        for key in backlog_message:
            data_to_post.append(
                {
                    "timestamp": key,
                    "backlog_message_count": backlog_message[key],
                    "oldest_unacked_message_age": oldest_unacked_message[key],
                }
            )
        post_data(json.dumps(data_to_post), consts.LOG_TYPE)
        applogger.info(
            "{}(method={}) : {} : WebTx metrics posted.".format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.NETSKOPE_WEBTX,
            )
        )
    except KeyError as error:
        applogger.error(
            "{}(method={}) : {} : KeyError: {}".format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.NETSKOPE_WEBTX,
                error,
            )
        )
        raise NetskopeException()
    except NetskopeException as error:
        applogger.error(
            "{}(method={}) : {} : Error: {}".format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.NETSKOPE_WEBTX,
                error,
            )
        )
        raise NetskopeException()
    except Exception as error:
        applogger.error(
            "{}(method={}) : {} : Error: {}".format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.NETSKOPE_WEBTX,
                error,
            )
        )
        raise NetskopeException()
