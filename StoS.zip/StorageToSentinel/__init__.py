"""Init for Netskope Azure storage to Sentinel."""
import datetime
import logging

import azure.functions as func
from .netskope_azure_storage_to_sentinel import NetskopeAzureStorageToSentinel
from ..SharedCode import utils


async def main(mytimer: func.TimerRequest) -> None:
    """Driver method for azure storage to sentinel."""
    utc_timestamp = datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()

    event_type_sub_type = utils.get_event_alert_type_subtype()
    sharename = event_type_sub_type.get("type_of_data") + event_type_sub_type.get("sub_type") + "data"
    state_manager_to_sentinel_obj = NetskopeAzureStorageToSentinel(sharename)
    await state_manager_to_sentinel_obj.driver_code()
    if mytimer.past_due:
        logging.info("The timer is past due!")

    logging.info("Python timer trigger function ran at %s", utc_timestamp)
