"""Module with constants and configurations for the Mimecast integration."""

import os

LOG_LEVEL = os.environ.get("LogLevel", "INFO")
LOGS_STARTS_WITH = "Mimecast"
LOG_FORMAT = "{}(method = {}) : {} : {}"


# *Sentinel related constants
WORKSPACE_KEY = os.environ.get("WorkspaceKey", "")
WORKSPACE_ID = os.environ.get("WorkspaceID", "")

# *Mimecast related constants
MIMECAST_CLIENT_ID = os.environ.get("Mimecast_Client_ID", "")
MIMECAST_CLIENT_SECRET = os.environ.get("Mimecast_Client_Secret", "")

BASE_URL = os.environ.get("BaseURL", "")
ENDPOINTS = {
    "OAUTH2": "/oauth/token",
    "PERFORMANCE_DETAILS": "/api/awareness-training/company/get-performance-details",
    "CAMPAIGN_DATA": "/api/awareness-training/phishing/campaign/get-campaign",
    "USER_DATA": "/api/awareness-training/phishing/campaign/get-user-data",
}

TABLE_NAME = {"PERFORMANCE_DETAILS": "Awareness_Performance_Details1", "USER_DATA": "Awareness_User_Data"}
AWARENESS_PERFORMANCE_FUNCTION_NAME = "Awareness Training Performance Details"
AWARENESS_USER_DATA_FUNCTION_NAME = "Awareness Training Phising User Data"


# *Error Messages for Exception
UNEXPECTED_ERROR_MSG = "Unexpected error : Error-{}."
HTTP_ERROR_MSG = "HTTP error : Error-{}."
REQUEST_ERROR_MSG = "Request error : Error-{}."
CONNECTION_ERROR_MSG = "Connection error : Error-{}."
KEY_ERROR_MSG = "Key error : Error-{}."
TYPE_ERROR_MSG = "Type error : Error-{}."
VALUE_ERROR_MSG = "Value error : Error-{}."
JSON_DECODE_ERROR_MSG = "JSONDecode error : Error-{}."

# *checkpoint related constants
CONN_STRING = os.environ.get("AzureWebJobsStorage", "")
FILE_SHARE_NAME = "awareness-training"
PERFORMANCE_CHECKPOINT_FILE = "performance_details"

# *Extra constants
MAX_RETRIES = 3
